from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def guide():
    return render_template("guide.html")

@app.route("/nameinpome")
def nameinPome():
    return render_template("nameinpome.html")

@app.route("/flower")
def flyFlower():
    return render_template("flower.html")

@app.route("/qanda")
def QaA():
    return render_template("qanda.html")


if __name__ == '__main__':
    app.run()
